package com.caffe;

import javax.swing.JOptionPane;

public class Cafe extends Drink {
    
    public Cafe(String sabor, double valor) {
        super(sabor, valor);
    }
    
    public void selecionar(int numero){
        
       double[] lista = new double [6];
       
       lista[0] = 1.30;
       lista[1] = 1.80;
       lista[2] = 4.00;
       lista[3] = 5.00;
       lista[4] = 3.50;
       lista[5] = 8.00;
       
        
        switch(numero){
            case 1: JOptionPane.showMessageDialog(null, "Café Puro");
                    this.setValor(lista[0]);
                    JOptionPane.showMessageDialog(null, "Valor: R$" + this.getValor());
                    qtdCafe(1);
            break;
            
            case 2: JOptionPane.showMessageDialog(null, "Café com Leite");
                    this.setValor(lista[1]);
                    JOptionPane.showMessageDialog(null, "Valor: R$" + this.getValor());
            break;
            
            case 3: JOptionPane.showMessageDialog(null, "Café Latte");
                    this.setValor(lista[2]);
                    JOptionPane.showMessageDialog(null, "Valor: R$" + this.getValor());
            break;
            
            case 4: JOptionPane.showMessageDialog(null, "Capuccino");
                    this.setValor(lista[3]);
                    JOptionPane.showMessageDialog(null, "Valor: R$" + this.getValor());
            break;
            
            case 5: JOptionPane.showMessageDialog(null, "Café com Chocolate");
                    this.setValor(lista[4]);
                    JOptionPane.showMessageDialog(null, "Valor: R$" + this.getValor());
            break;
            
            case 6: JOptionPane.showMessageDialog(null, "Café Java");
                    this.setValor(lista[5]);
                    JOptionPane.showMessageDialog(null, "Valor: R$" + this.getValor());
            break;
            
            default: JOptionPane.showMessageDialog(null, "Nenhuma das Opções");
        }
        
        
    }
    
    public int qtdCafe(int num){
        
        //estoque de doses de café
        int toq = 10 - num;
        
        if (toq > 0 && toq < 11) {
        JOptionPane.showMessageDialog(null, "Em preparo...");
        return 1;
        } else {
        JOptionPane.showMessageDialog(null, "Sem café!");
        return 0;
}
    
    //return 0;
    
    
    
}
    
}
